<?php
    //Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

include_once '../../config/Database.php';
include_once '../../models/UserPoint.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//Insantiate user$userPoint$userPoint Table Model
$userPoint = new UserPoint($db);

// Get all user$userPoint$userPoint info
$result = $userPoint->read();

//Get row Count
$num = $result->rowCount();

//Check if any user$userPoint$userPoint
if($num > 0){
    $userPoint_arr = array();

    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        # code...
        extract($row);
        //SELECT u.id as u_id, u.user_role_id as u_role_id, u.full_name, u.email_address, u.password,u.mobile,u.photo,u.create_date as u_create_date, u.update_date, ur.role_type, ur.description, ur.create_date as u_role_create_date FROM user$userPoint_table as u JOIN user_role as ur on ur.id = u.user_role_id WHERE u.id = 1
        
        $userPoint_item = array(
            'id' => $id,
            'user_id' => $user_id,
            'full_name' => $full_name,
            'email_address' => $email_address,
            'current_point' => $current_point,
            'used_point' => $used_point,
            'total_point' => $total_point,
            'comment' => $comment
        );

        json_encode($userPoint_item,JSON_FORCE_OBJECT);

        //Push to "data"
        array_push($userPoint_arr, $userPoint_item);
    }

    //Turn to Json & output
    echo json_encode($userPoint_arr);
}else{
    echo json_encode(
        array('message' => 'No Data Found')
    );
}

?>