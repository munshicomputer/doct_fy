<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

  include_once '../../config/Database.php';
  include_once '../../models/UserPoint.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate blog post object
  $userPoint = new UserPoint($db);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

  // Get raw posted data
  $data = json_decode(file_get_contents('php://input'), true);

  if (empty($data)) {
  } else {
    $userPoint->user_id = $data['user_id'];
    $userPoint->current_point = $data['current_point'];
    $userPoint->used_point = $data['used_point'];
    $userPoint->total_point = $data['total_point'];
    $userPoint->comment = $data['comment'];

    // Create User Role

    if ($userPoint->create()) {
      echo json_encode(array('message' => 'User Role Created'));
    } else {
      echo json_encode(array('message' => 'User Role Not Created'));
    }
  }
}
?>