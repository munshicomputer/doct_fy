<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');

  include_once '../../config/Database.php';
  include_once '../../models/UserPoint.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate user role object
  $userpoint = new UserPoint($db);

  // Get ID
  $userpoint->id = isset($_GET['id']) ? $_GET['id'] : die();

  // Get userpoint$userpoint$userpoint
  $userpoint->read_single();
  

  // Create array
  $userpoint_arr = array(
    'id' => $userpoint->id,
    'user_id' => $userpoint->user_id,
    'full_name' => $userpoint->full_name,
    'email_address' => $userpoint->email_address,
    'current_point' => $userpoint->current_point,
    'used_point' => $userpoint->used_point,
    'total_point' => $userpoint->total_point,
    'comment' => $userpoint->comment
  );

  // Make JSON
  echo json_encode($userpoint_arr);
  ?>