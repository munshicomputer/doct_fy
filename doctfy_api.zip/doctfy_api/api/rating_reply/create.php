<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

  include_once '../../config/Database.php';
  include_once '../../models/RatingReply.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate blog post object
  $rating = new RatingReply($db);

  if($_SERVER['REQUEST_METHOD'] === 'POST'){

      // Get raw posted data
    $data = json_decode(file_get_contents('php://input'),true);
  
    if (empty($data)) {
    } else {
        $rating->user_id = $data['user_id'];
        $rating->rating_id = $data['rating_id'];
        $rating->rating_reply = $data['rating_reply'];

      // Create User Role
        if($rating->create()) {
           echo json_encode(array('message' => 'Rating Reply Created'));
        } else {
          echo json_encode(array('message' => 'Rating Reply Not Created'));
        }
    }
  }
?>