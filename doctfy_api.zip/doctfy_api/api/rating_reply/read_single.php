<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');

  include_once '../../config/Database.php';
  include_once '../../models/RatingReply.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate user role object
  $rating = new RatingReply($db);

  // Get ID
  $rating->id = isset($_GET['id']) ? $_GET['id'] : die();

  // Get rating$rating
  $rating->read_single();

  // Create array
  $rating_arr = array(
    'id' => $rating->id,
    'user_id' => $rating->user_id,
    'full_name' => $rating->full_name,
    'photo' => $rating->photo,
    'rating_id' => $rating->rating_id,
    'rating_comment' => $rating->rating_comment,
    'rating_reply' => $rating->rating_reply,
    'create_date' => $rating->create_date
  );

  // Make JSON
  echo json_encode($rating_arr);
  ?>