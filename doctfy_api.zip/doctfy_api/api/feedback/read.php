<?php
    //Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

include_once '../../config/Database.php';
include_once '../../models/FeedBack.php';

//Instantiate DB & Connect
$database = new Database();
$db = $database->connect();

//Insantiate feedback$feedback Table Model
$feedback = new FeedBack($db);

// Get all feedback$feedback info
$result = $feedback->read();

//Get row Count
$num = $result->rowCount();

//Check if any feedback$feedback
if($num > 0){
    $feedback_arr = array();

    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        # code...
        extract($row);
        //SELECT u.id as u_id, u.user_role_id as u_role_id, u.full_name, u.email_address, u.password,u.mobile,u.photo,u.create_date as u_create_date, u.update_date, ur.role_type, ur.description, ur.create_date as u_role_create_date FROM feedback_table as u JOIN user_role as ur on ur.id = u.user_role_id WHERE u.id = 1
        
        $feedback_item = array(
            'id' => $id,
            'user_id' => $user_id,
            'full_name' => $full_name,
            'email_address' => $email_address,
            'photo' => $photo,
            'feedback_title' => $feedback_title,
            'feedback_description' => $feedback_description,
            'create_date' => $create_date
        );

        json_encode($feedback_item,JSON_FORCE_OBJECT);

        //Push to "data"
        array_push($feedback_arr, $feedback_item);
    }

    //Turn to Json & output
    echo json_encode($feedback_arr);
}else{
    echo json_encode(
        array('message' => 'No Data Found')
    );
}

?>