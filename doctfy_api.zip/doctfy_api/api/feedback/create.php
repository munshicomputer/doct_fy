<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

  include_once '../../config/Database.php';
  include_once '../../models/FeedBack.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate blog post object
  $feedback = new FeedBack($db);

  if($_SERVER['REQUEST_METHOD'] === 'POST'){

      // Get raw posted data
    $data = json_decode(file_get_contents('php://input'),true);
  
    if (empty($data)) {
    } else {
        $feedback->user_id = $data['user_id'];
        $feedback->feedback_title = $data['feedback_title'];
        $feedback->feedback_description = $data['feedback_description'];

      // Create User Role
          if($feedback->create()) {
            echo json_encode(array('message' => 'Feedback Created'));
          } else {
            echo json_encode(array('message' => 'Feedback Not Created'));
          }
        }
      }
?>