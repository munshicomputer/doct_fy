<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');

  include_once '../../config/Database.php';
  include_once '../../models/FeedBack.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate user role object
  $feedback = new FeedBack($db);

  // Get ID
  $feedback->id = isset($_GET['id']) ? $_GET['id'] : die();

  // Get feedback$feedback
  $feedback->read_single();
  

  // Create array
  $feedback_arr = array(
    'id' => $feedback->id,
    'user_id' => $feedback->user_id,
    'full_name' => $feedback->full_name,
    'email_address' => $feedback->email_address,
    'photo' => $feedback->photo,
    'feedback_title' => $feedback->feedback_title,
    'feedback_description' => $feedback->feedback_description,
    'create_date' => $feedback->create_date
  );

  // Make JSON
  echo json_encode($feedback_arr);
  ?>