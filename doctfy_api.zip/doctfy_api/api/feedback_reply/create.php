<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

  include_once '../../config/Database.php';
  include_once '../../models/FeebackReply.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate blog post object
  $feedbackreply = new FeedBackReply($db);

  if($_SERVER['REQUEST_METHOD'] === 'POST'){

      // Get raw posted data
    $data = json_decode(file_get_contents('php://input'),true);
  
    if (empty($data)) {
    } else {
        $feedbackreply->user_id = $data['user_id'];
        $feedbackreply->feedback_id = $data['feedback_id'];
        $feedbackreply->reply_message = $data['reply_message'];

      // Create User Role
          if($feedbackreply->create()) {
            echo json_encode(array('message' => 'Feedback Reply Created'));
          } else {
            echo json_encode(array('message' => 'Feedback Reply Not Created'));
          }
        }
      }
?>