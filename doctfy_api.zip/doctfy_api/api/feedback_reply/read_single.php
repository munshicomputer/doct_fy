<?php 
  // Headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json');

  include_once '../../config/Database.php';
  include_once '../../models/FeebackReply.php';

  // Instantiate DB & connect
  $database = new Database();
  $db = $database->connect();

  // Instantiate user role object
  $feedbackreply = new FeedBackReply($db);

  // Get ID
  $feedbackreply->id = isset($_GET['id']) ? $_GET['id'] : die();

  // Get feedbackreply$feedbackreply
  $feedbackreply->read_single();
  

  // Create array
  $feedbackreply_arr = array(
    'id' => $feedbackreply->id,
    'user_id' => $feedbackreply->user_id,
    'full_name' => $feedbackreply->full_name,
    'email_address' => $feedbackreply->email_address,
    'photo' => $feedbackreply->photo,
    'feedback_id' =>$feedbackreply->feedback_id,
    'feedback_title' => $feedbackreply->feedback_title,
    'feedback_description' => $feedbackreply->feedback_description,
    'reply_message' => $feedbackreply->reply_message,
    'create_date' => $feedbackreply->create_date
  );

  // Make JSON
  echo json_encode($feedbackreply_arr);
  ?>