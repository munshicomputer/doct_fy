<?php
    class FeedBackReply{
        //DB Stuff
    private $conn;
    private $table = 'feedback_reply';
    private $joinUsersTable = 'users_table';
    private $joinFeedbackTable = "feedbac_table";

    // Department Properties
    public $id;
    public $user_id;
    public $full_name;
    public $email_address;
    public $photo;
    public $feedback_id;
    public $feedback_title;
    public $feedback_description;
    public $reply_message;
    public $create_date;

    
    // Constructor with DB
    public function __construct($db){
        $this->conn = $db;
    }

    // Get All UserRole
    public function read(){
        // Create Query
        // $query = 'SELECT u.id as u_id, u.*, ur.* FROM '. $this->table .' as u JOIN '.$this->joinTable.' as ur on ur.id = u.user_role_id';

        //SELECT u.id as u_id, u.user_role_id as u_role_id, u.full_name, u.email_address, u.password,u.mobile,u.photo,u.create_date as u_create_date, u.update_date, ur.role_type, ur.description, ur.create_date as u_role_create_date FROM users_table as u JOIN user_role as ur on ur.id = u.user_role_id WHERE u.id = 1

        $query = 'SELECT fr.id, f.user_id, u.full_name, u.email_address,u.photo, fr.feedback_id, f.feedback_description, f.feedback_title, fr.reply_message, fr.create_date FROM '.$this->table.' as fr JOIN '.$this->joinUsersTable.' as u on u.id = fr.user_id JOIN '.$this->joinFeedbackTable.' as f on f.id = fr.feedback_id';

        //Prepare Statement
        $statement = $this->conn->prepare($query);

        //Execute Query
        $statement->execute();

        return $statement;
    }

    // Get Single UserRole Data
    public function read_single() {
        // Create query
        $query = 'SELECT fr.id, f.user_id, u.full_name, u.email_address,u.photo, fr.feedback_id, f.feedback_description, f.feedback_title, fr.reply_message, fr.create_date FROM '.$this->table.' as fr JOIN '.$this->joinUsersTable.' as u on u.id = fr.user_id JOIN '.$this->joinFeedbackTable.' as f on f.id = fr.feedback_id WHERE fr.id = ?';

        // Prepare statement
        $statement = $this->conn->prepare($query);

        // Bind ID
        $statement->bindParam(1, $this->id);

        // Execute query
        $statement->execute();

        $row = $statement->fetch(PDO::FETCH_ASSOC);

        if($row > 0){
          // Set properties
          $this->id = $row['id'];
          $this->user_id = $row['user_id'];
          $this->full_name = $row['full_name'];
          $this->email_address = $row['email_address'];
          $this->photo = $row['photo'];
          $this->feedback_id = $row['feedback_id'];
          $this->feedback_title = $row['feedback_title'];
          $this->feedback_description = $row['feedback_description'];
          $this->reply_message = $row['reply_message'];
          $this->create_date = $row['create_date'];
        }
        
  }

  // Create UserRole
  public function create() {
        // Create query
        $query = 'INSERT INTO ' . $this->table . ' SET user_id = :user_id, feedback_id = :feedback_id, reply_message = :reply_message';

        // Prepare statement
        $stmt = $this->conn->prepare($query);

        // Clean data
        $this->user_id = htmlspecialchars(strip_tags($this->user_id));
        $this->feedback_id = htmlspecialchars(strip_tags($this->feedback_id));
        $this->reply_message = htmlspecialchars(strip_tags($this->reply_message));


        // Bind data
        $stmt->bindParam(':user_id', $this->user_id);
        $stmt->bindParam(':feedback_id', $this->feedback_id);
        $stmt->bindParam(':reply_message', $this->reply_message);

        // Execute query
        if($stmt->execute()) {
          return true;
    }

    // Print error if something goes wrong
    printf("Error: %s.\n", $stmt->error);

    return false;
  }

  // Update USER_ROLE
  public function update() {
        // Create query
        $query = 'UPDATE ' . $this->table . ' SET user_id = :user_id, feedback_id = :feedback_id, reply_message = :reply_message WHERE id = :id';

        // Prepare statement
        $stmt = $this->conn->prepare($query);

        // Clean data
        $this->user_id = htmlspecialchars(strip_tags($this->user_id));
        $this->feedback_id = htmlspecialchars(strip_tags($this->feedback_id));
        $this->reply_message = htmlspecialchars(strip_tags($this->reply_message));
        $this->id = htmlspecialchars(strip_tags($this->id));
        //Date for update not initialize.

        // Bind data
        $stmt->bindParam(':user_id', $this->user_id);
        $stmt->bindParam(':feedback_id', $this->feedback_id);
        $stmt->bindParam(':reply_message', $this->reply_message);
        $stmt->bindParam(':id', $this->id);

        // Execute query
        if($stmt->execute()) {
          return true;
        }

        // Print error if something goes wrong
        printf("Error: %s.\n", $stmt->error);

        return false;
  }

  // Delete USER ROLE
  public function delete() {
        // delete query
        $query = 'DELETE FROM ' . $this->table . ' WHERE id = :id';

        // Prepare statement
        $stmt = $this->conn->prepare($query);

        // Clean data
        $this->id = htmlspecialchars(strip_tags($this->id));

        // Bind data
        $stmt->bindParam(':id', $this->id);

        // Execute query
        if($stmt->execute()) {
          return true;
        }

        // Print error if something goes wrong
        printf("Error: %s.\n", $stmt->error);

        return false;
  }
}
  
?>