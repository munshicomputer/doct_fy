<?php
    class FeedBack{
        //DB Stuff
    private $conn;
    private $table = 'feedbac_table';
    private $joinTable = 'users_table';

    // Department Properties
    public $id;
    public $user_id;
    public $full_name;
    public $email_address;
    public $photo;
    public $feedback_title;
    public $feedback_description;
    public $create_date;

    
    // Constructor with DB
    public function __construct($db){
        $this->conn = $db;
    }

    // Get All UserRole
    public function read(){
        // Create Query
        // $query = 'SELECT u.id as u_id, u.*, ur.* FROM '. $this->table .' as u JOIN '.$this->joinTable.' as ur on ur.id = u.user_role_id';

        //SELECT u.id as u_id, u.user_role_id as u_role_id, u.full_name, u.email_address, u.password,u.mobile,u.photo,u.create_date as u_create_date, u.update_date, ur.role_type, ur.description, ur.create_date as u_role_create_date FROM users_table as u JOIN user_role as ur on ur.id = u.user_role_id WHERE u.id = 1

        $query = 'SELECT f.id, f.user_id, u.full_name, u.email_address,u.photo, f.feedback_description, f.feedback_title, f.create_date FROM '.$this->table.' as f JOIN '.$this->joinTable.' as u on u.id = f.user_id';

        //Prepare Statement
        $statement = $this->conn->prepare($query);

        //Execute Query
        $statement->execute();

        return $statement;
    }

    // Get Single UserRole Data
    public function read_single() {
        // Create query
        $query = 'SELECT f.id, f.user_id, u.full_name, u.email_address,u.photo, f.feedback_description, f.feedback_title, f.create_date FROM '.$this->table.' as f JOIN '.$this->joinTable.' as u on u.id = f.user_id WHERE f.id = ?';

        // Prepare statement
        $statement = $this->conn->prepare($query);

        // Bind ID
        $statement->bindParam(1, $this->id);

        // Execute query
        $statement->execute();

        $row = $statement->fetch(PDO::FETCH_ASSOC);

        if($row > 0){
          // Set properties
          $this->id = $row['id'];
          $this->user_id = $row['user_id'];
          $this->full_name = $row['full_name'];
          $this->email_address = $row['email_address'];
          $this->photo = $row['photo'];
          $this->feedback_title = $row['feedback_title'];
          $this->feedback_description = $row['feedback_description'];
          $this->create_date = $row['create_date'];
        }
        
  }

  // Create UserRole
  public function create() {
        // Create query
        $query = 'INSERT INTO ' . $this->table . ' SET user_id = :user_id, feedback_title = :feedback_title, feedback_description = :feedback_description';

        // Prepare statement
        $stmt = $this->conn->prepare($query);

        // Clean data
        $this->user_id = htmlspecialchars(strip_tags($this->user_id));
        $this->feedback_title = htmlspecialchars(strip_tags($this->feedback_title));
        $this->feedback_description = htmlspecialchars(strip_tags($this->feedback_description));


        // Bind data
        $stmt->bindParam(':user_id', $this->user_id);
        $stmt->bindParam(':feedback_title', $this->feedback_title);
        $stmt->bindParam(':feedback_description', $this->feedback_description);

        // Execute query
        if($stmt->execute()) {
          return true;
    }

    // Print error if something goes wrong
    printf("Error: %s.\n", $stmt->error);

    return false;
  }

  // Update USER_ROLE
  public function update() {
        // Create query
        $query = 'UPDATE ' . $this->table . ' SET user_id = :user_id, feedback_title = :feedback_title, feedback_description = :feedback_description WHERE id = :id';

        // Prepare statement
        $stmt = $this->conn->prepare($query);

        // Clean data
        $this->user_id = htmlspecialchars(strip_tags($this->user_id));
        $this->feedback_title = htmlspecialchars(strip_tags($this->feedback_title));
        $this->feedback_description = htmlspecialchars(strip_tags($this->feedback_description));
        $this->id = htmlspecialchars(strip_tags($this->id));
        //Date for update not initialize.

        // Bind data
        $stmt->bindParam(':user_id', $this->user_id);
        $stmt->bindParam(':feedback_title', $this->feedback_title);
        $stmt->bindParam(':feedback_description', $this->feedback_description);
        $stmt->bindParam(':id', $this->id);

        // Execute query
        if($stmt->execute()) {
          return true;
        }

        // Print error if something goes wrong
        printf("Error: %s.\n", $stmt->error);

        return false;
  }

  // Delete USER ROLE
  public function delete() {
        // delete query
        $query = 'DELETE FROM ' . $this->table . ' WHERE id = :id';

        // Prepare statement
        $stmt = $this->conn->prepare($query);

        // Clean data
        $this->id = htmlspecialchars(strip_tags($this->id));

        // Bind data
        $stmt->bindParam(':id', $this->id);

        // Execute query
        if($stmt->execute()) {
          return true;
        }

        // Print error if something goes wrong
        printf("Error: %s.\n", $stmt->error);

        return false;
  }
}
  
?>